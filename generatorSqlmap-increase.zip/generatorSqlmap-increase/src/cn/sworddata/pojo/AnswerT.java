package cn.sworddata.pojo;

import java.io.Serializable;
import java.util.Date;

public class AnswerT implements Serializable {
    /**
     * 主键ID
     */
    private Integer id;

    /**
     * 用户id
     */
    private String userId;

    /**
     * 测试的唯一编号UUID
     */
    private String testId;

    /**
     * 完成测试的时间
     */
    private Date finishedTime;

    /**
     * 问卷ID
     */
    private String paperId;

    /**
     * 备注
     */
    private String remark;

    /**
     * 测试所用时间(秒)
     */
    private Integer testTime;

    /**
     * 存放一整套试题的答案
     */
    private String answers;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public String getTestId() {
        return testId;
    }

    public void setTestId(String testId) {
        this.testId = testId == null ? null : testId.trim();
    }

    public Date getFinishedTime() {
        return finishedTime;
    }

    public void setFinishedTime(Date finishedTime) {
        this.finishedTime = finishedTime;
    }

    public String getPaperId() {
        return paperId;
    }

    public void setPaperId(String paperId) {
        this.paperId = paperId == null ? null : paperId.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Integer getTestTime() {
        return testTime;
    }

    public void setTestTime(Integer testTime) {
        this.testTime = testTime;
    }

    public String getAnswers() {
        return answers;
    }

    public void setAnswers(String answers) {
        this.answers = answers == null ? null : answers.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", userId=").append(userId);
        sb.append(", testId=").append(testId);
        sb.append(", finishedTime=").append(finishedTime);
        sb.append(", paperId=").append(paperId);
        sb.append(", remark=").append(remark);
        sb.append(", testTime=").append(testTime);
        sb.append(", answers=").append(answers);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}