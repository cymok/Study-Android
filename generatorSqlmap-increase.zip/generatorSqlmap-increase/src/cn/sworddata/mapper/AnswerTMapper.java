package cn.sworddata.mapper;

import cn.sworddata.pojo.AnswerT;
import cn.sworddata.pojo.AnswerTExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AnswerTMapper {
    int countByExample(AnswerTExample example);

    int deleteByExample(AnswerTExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(AnswerT record);

    int insertSelective(AnswerT record);

    List<AnswerT> selectByExampleWithBLOBs(AnswerTExample example);

    List<AnswerT> selectByExample(AnswerTExample example);

    AnswerT selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AnswerT record, @Param("example") AnswerTExample example);

    int updateByExampleWithBLOBs(@Param("record") AnswerT record, @Param("example") AnswerTExample example);

    int updateByExample(@Param("record") AnswerT record, @Param("example") AnswerTExample example);

    int updateByPrimaryKeySelective(AnswerT record);

    int updateByPrimaryKeyWithBLOBs(AnswerT record);

    int updateByPrimaryKey(AnswerT record);
}